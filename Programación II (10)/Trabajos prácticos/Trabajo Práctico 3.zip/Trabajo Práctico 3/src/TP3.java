import java.util.InputMismatchException;

public class TP3 {
    public static void main(String[] args) throws Exception {

        Menu menu = new Menu();

        menu.mostrarMenu();
    }
}
