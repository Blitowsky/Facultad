Último commit de las ramas

Hice el merge de las ramas basedatosjdbc y el main para que el main ya esté un poco más actualizado

Hay que mejorar el diseño de algunas ventanas, botones, etc porque la verdad que no tengo ni idea de como se hace. Además hay que ver el tema de que cuando ejecutas si la pantalla a mostrar es más grande que el cuadradito de ejecucuón esta se corta y directamente no se ve (si no me expliqué muy bien fijense que pasa en el vendedor en ver vehiculos)

La verificicación está comentada porque sino no me dejaba entrar

Ejecuten y traten de romper y clickear todo lo nuevo porfa así ya para el viernes podemos saber mejor que es lo que falta :)
