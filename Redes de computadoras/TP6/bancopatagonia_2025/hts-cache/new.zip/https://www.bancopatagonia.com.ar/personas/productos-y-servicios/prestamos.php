<!DOCTYPE html>
<html lang="es">
<head>
<script type="text/javascript">
window.location = "../prestamos/index.php";
</script>
</head>
<body>
</body>
</html>