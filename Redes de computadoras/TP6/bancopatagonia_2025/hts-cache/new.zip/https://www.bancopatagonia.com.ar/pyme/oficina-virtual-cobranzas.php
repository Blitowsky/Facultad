<!DOCTYPE html>
<html lang="es">
<head>
<script type="text/javascript">
window.location = "oficina-virtual-cobranzas/index.php";
</script>
</head>
<body>
</body>
</html>