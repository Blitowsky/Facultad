<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="0">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Información al Usuario Financiero | Banco Patagonia</title>
	<meta name="description" content="Comisiones, cargos y tasas - Promociones Vigentes - Información Útil para usuarios de Servicios Financieros">
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon"/>
<link href="../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->    <style>
        /*h1 span { font-family: "Roboto"; }*/
        .btn-lnk-block h3 { margin-bottom: 0px;}
    </style>
    
    <!-- -------- -->
    <!-- POP (ME) -->
    <!-- -------- -->
    <style>
    .pop-port { display:none !important;}
    @media screen and (max-width: 820px) {
        .pop-desk { display:none !important;}
        .pop-port { display:inline-block !important;}
    }
    </style>
    <!-- -->
    <script type="text/javascript">
        function popMonedaExtranjera() { 
            var url="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/cotizacionMonedaExtranjera.htm";
            var Wnd=window.open(url,"H1","toolbar=0,location=0,status=0,menubar=0,scrollbars=yes,width=460,height=320,top=0,left=0");
        }
    </script>
    <!-- -->
    
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                <li id="btn-hacete-cliente"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank"><strong>Hacete cliente <i class="fa fa-angle-right"></i></strong></a></li>								<li><a href="../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="index.php" class="">PERSONAS</a></li>
								<li><a href="../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../pyme/index.php" class="">PYME</a></li>
								<li><a href="../agro/index.php" class="">AGRO</a></li>
								<li><a href="../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="patagonia-ebank" target="_blank">Patagonia e-Bank</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
												<!-- PERSONAS -->
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA ON</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
								<li><a href="../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
							</ul>
						</li>
                        <li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA CLÁSICA</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                                <li><a href="../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA PLUS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                                <li><a href="../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
							</ul>						
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA SINGULAR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                                <li><a href="../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PRODUCTOS Y SERVICIOS</a>
							<ul class="list-unstyled submenu">
								<li><a href="https://ahorrosybeneficios.bancopatagonia.com.ar/ahorrosybeneficios/" target="_blank">Beneficios</a></li>
                                <li><a href="../personas/apple-pay.php">Apple Pay</a></li>
                                <li><a href="../personas/productos-y-servicios/cajas-seguridad.php">Caja de Seguridad</a></li>
                                <li><a href="../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
								<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
								<li><a href="../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
								<li><a href="../personas/google-pay.php">Google Pay</a></li>
                                <li><a href="inversiones/index.php">Inversiones</a></li>
                                <li><a href="../personas/jubilados/index.php">Jubilados</a></li>
                                <li><a href="../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                                <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
								<li><a href="../personas/plan-sueldo/index.php">Patagonia Sueldo</a></li>
								<li><a href="../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                                <li><a href="../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                                <li><a href="../personas/seguros/index.php">Seguros</a></li>
                                <li><a href="../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
								<li><a href="../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
							</ul>
						</li>
						<!-- FIN PERSONAS -->
						                        
                                                
                                                
                        						
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
						<li><a href="https://ahorrosybeneficios.bancopatagonia.com.ar/ahorrosybeneficios/" target="_blank">Beneficios</a></li>
                        <li><a href="../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../personas/productos-y-servicios/cajas-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="inversiones/index.php">Inversiones</a></li>
                        <li><a href="../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
						<li><a href="../personas/plan-sueldo/index.php">Patagonia Sueldo</a></li>
						<li><a href="../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="inversiones/index.php">Inversiones</a></li>
                        <li><a href="../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../personas/productos-y-servicios/cajas-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../pyme/oficina-virtual-cobranzas.php">Oficina virtual de Cobros</a></li>
						<li><a href="../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../empresas/oficina-virtual-cobranzas.php">Oficina virtual de Cobros</a></li>
                        <li><a href="../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/oficina-virtual-cobranzas.php">Oficina virtual de Cobros</a></li>
						<li><a href="../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        <li class="nav-main-item"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank" style="text-transform: none;">Hacete cliente</a></li>		<li class="nav-main-item"><a href="../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="index.php">Personas</a></li>
					<li class="active">Información al Usuario Financiero</li>
				</ol>
			</div>
		</div>
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="text-data">
					<h1>Información al Usuario Financiero</h1>
					<h3><strong>Comisiones, cargos y tasas</strong></h3>
					<div class="row">
						<!-- -->
						<div class="col-md-4 col-sm-6 col-xs-12">
							<a href="comisiones-y-cargos.php" class="btn-lnk-block">
								<h3>Comisiones y Cargos</h3>
								<i class="icon icon-more"></i>
							</a>
						</div>
						<!-- botón -->
						<div class="col-md-4 col-sm-6 col-xs-12">
							<!--<a href="inversiones/plazo-fijo.php" class="btn-lnk-block">-->
							<a href="#tasas" data-toggle="modal" class="btn-lnk-block">
								<h3>Tasas</h3>
								<i class="icon icon-more"></i>
							</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="tasas">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="text-data">
											<p>&nbsp;</p>
											<h3 class="clr-clasica"><strong>Tasas</strong></h3>
											<!-- -->
											<div class="row">
												<div class="col-md-6 col-sm-6 col-xs-12">
													<!--<a href="<php echo $folder_inversiones ?>plazo-fijo.php" class="btn-lnk-block">-->
													<a href="inversiones/docs/Tasas_Plazo_Fijo.pdf" target="_blank" class="btn-lnk-block">
														<h4>Tasas de Plazo Fijo</h4>
														<i class="icon icon-pdf"></i>
													</a>
												</div>
												<div class="col-md-6 col-sm-6 col-xs-12">
													<a href="../comisiones/docs/DC0034_Prestamos.pdf" target="_blank" class="btn-lnk-block">
														<h4>Tasas y Comisiones de Préstamos</h4>
														<i class="icon icon-pdf"></i>
													</a>
												</div>
												<div class="col-md-6 col-sm-6 col-xs-12">
													<a href="../comisiones/docs/Tasas_Financiacion_TC.pdf" target="_blank" class="btn-lnk-block">
														<h4>Tasas de Financiación TC</h4>
														<i class="icon icon-pdf"></i>
													</a>
												</div>
											</div>
											<!-- -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
						<!-- -->
					</div>
					<hr>
					<h3><strong>Promociones Vigentes</strong></h3>
					<div class="row">
						<div class="col-md-4 col-sm-6 col-xs-12">
							<a href="http://ahorrosybeneficios.bancopatagonia.com.ar/" target="_blank" class="btn-lnk-block">
								<h3>Ahorros y Beneficios</h3>
								<i class="icon icon-more"></i>
							</a>
						</div>
						<div class="col-md-4 col-sm-6 col-xs-12">
							<a href="../atencionexclusiva/beneficios-patagonia-mas.shtml" target="_blank" class="btn-lnk-block">
								<h3>Beneficios Atención exclusiva</h3>
								<i class="icon icon-more"></i>
							</a>
						</div>
						<div class="col-md-4 col-sm-6 col-xs-12">
							<a href="tarjetas/beneficios.php" class="btn-lnk-block">
								<h3>Beneficios Semanales</h3>
								<i class="icon icon-more"></i>
							</a>
						</div>
					</div>
					<hr>
					<h3><strong>Información Útil para usuarios de Servicios Financieros</strong></h3>
					<div>
                        <!-- Acuerdo en Acción de Clase Comisión Intersucursal -->
                        <!-- botón -->
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <a href="#aduc" data-toggle="modal" class="btn-lnk-block">
                                    <h3>Acuerdo en Acción de Clase Comisión Intersucursal</h3>
                                    <i class="icon icon-more"></i>
                                </a>
                            </div>
                        </div>
                        <!-- modal -->
                        <div class="modal fade" id="aduc">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
								  	<div class="modal-body">
										<h2>Acuerdo en Acción de Clase Comisión Intersucursal</h2>
                                        <p>&ldquo;Banco Patagonia S.A (en adelante, el &ldquo;Banco  Patagonia&rdquo;), celebró un acuerdo en el juicio &ldquo;ADUC c/ Banco Patagonia S.A s/  ordinario&rdquo; (Expediente Nº 13041/2018) que tramita ante el Juzgado Nacional de  Primera Instancia en lo Comercial Nº 17, Secretaría Nº 33. El expediente puede  verse ingresando a la página web de Poder Judicial de la Nación <a href="https://www.pjn.gov.ar/" target="_blank">https://www.pjn.gov.ar/</a> y también encontrarás el acuerdo conciliatorio completo en las páginas <a href="http://www.aduc.org.ar" target="_blank">www.aduc.org.ar</a>.</p>
                                        <p>Por lo dispuesto en ese acuerdo, Banco  Patagonia reintegrará ciertas sumas de dinero a sus clientes y ex clientes  consumidores del segmento &ldquo;Personas Físicas&rdquo; por operaciones en pesos en el  período comprendido entre el 13/11/2013 y el 13/11/2015 y a las &ldquo;Asociaciones  civiles sin fines de lucro&rdquo; por operaciones en pesos comprendido entre el  13/11/2015 y 15/10/2024.</p>
                                        <p>A los clientes de Banco Patagonia se le  acreditará dicho dinero en su cuenta. A los exclientes del Banco se les  realizará una transferencia al CBU/CVU que informe COELSA.</p>
                                        <p>Para aquellos exclientes sobre los  cuales Banco Patagonia no disponga de información acerca de una cuenta para  efectuar la transferencia, los fondos estarán disponibles para su retiro en  cualquier sucursal del Banco durante un plazo de dos años. Este plazo comenzará  a contarse después de 60 días hábiles judiciales desde el vencimiento del  período de exclusión previsto para los Beneficiarios. El vencimiento del  período de exclusión previsto para los Beneficiarios marcará el inicio del  conteo del plazo para el retiro, es decir,30 días hábiles desde la última  publicidad del Acuerdo. <p>Para realizar el retiro en sucursales, los exclientes  deberán presentar su DNI como requisito indispensable.</p>
                                        <p>Los clientes y exclientes de Banco  Patagonia que deseen excluirse de los efectos del acuerdo lo podrán hacer  enviando, dentro de los 30 días hábiles desde la finalización de las medidas de  publicidad, un correo electrónico <a href="mailto:comisionintersucursal@bancopatagonia.com.ar">comisionintersucursal@bancopatagonia.com.ar</a> con copia a <a href="mailto:info@aduc.org.ar">info@aduc.org.ar</a> manifestando que va a hacer uso del derecho de autoexclusión.&rdquo; </p>
									</div>
                                </div>
                            </div>
                        </div>
                    </div>
					<!--<div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <a href="acuerdo-mantenimiento-caja-ahorro-y-cuenta-corriente.php" class="btn-lnk-block">
                                    <h3>Acuerdo en acción colectiva Comisión de Mantenimiento en Caja de Ahorro y Cuenta Corriente</h3>
                                    <i class="icon icon-more"></i>
                                </a>
                            </div>
                        </div>
                    </div>-->
					<div>
                        <!-- Acción colectiva refinanciacion en tarjetas de crédito conforme Comunicación “A” 6964 y 7095 BCRA -->
                        <!-- botón -->
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <a href="#acuba" data-toggle="modal" class="btn-lnk-block">
                                    <h3>Acción colectiva refinanciación en tarjetas de crédito conforme Comunicación “A” 6964 y 7095 BCRA</h3>
                                    <i class="icon icon-more"></i>
                                </a>
                            </div>
                        </div>
                        <!-- modal -->
                        <div class="modal fade" id="acuba">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <h2>ACCION COLECTIVA: “ACUBA C/BANCO PATAGONIA S.A. S/ MATERIA A CATEGORIZAR” EXPTE. N° 118.118/2022. REFINANCIACION EN TARJETAS DE CRÉDITO CONFORME COMUNICACIÓN “A” 6964 Y 7095 BCRA.</h2>
                                        <p>El Juzgado Civil y Comercial N° 6 de Mar del Plata, a cargo de la Dra. Gabriela Judit De Sábato sito en Almirante Brown 2257, Piso 3, de la localidad de Mar del Plata, informa que con fecha 15/5/2022 la Asociación Civil de Usuarios Bancarios Argentinos (ACUBA) con domicilio en 12 de Octubre 3223 4to B de la localidad de Mar del Plata, promovió demanda colectiva contra Banco Patagonia S.A. con domicilio en Avenida de Mayo 701 de la Ciudad Autónoma de Buenos Aires, con el siguiente objeto: (i) se declare la ilegalidad de la financiación de aquellos saldos deudores de las tarjetas de crédito Visa y Mastercard con vencimiento de pago originalmente previsto entre los días 20/3/2020 y 30/4/2020, así como de aquellos con vencimiento de pago originalmente previsto entre los días 1/9/2020 y 30/9/2020, por considerar que fueron efectuadas en violación con las pautas establecidas en las Comunicaciones del BCRA; (ii) se declare la ilegalidad del cobro de los conceptos incluidos en los resúmenes de las tarjetas Mastercard: “INT. IMP. ANT. A6964”, “INT.COM.CUOTIF.A6964”, “INT. IMP. ANT. 17095” e “INT.COM.CUOTIF.A7095” ; (iii) se declare la ilegalidad del cobro de intereses por el período comprendido entre la fecha de vencimiento de cada resumen y la fecha de carga del mutuo; (iv) se ordene la readecuación de las referidas financiaciones que se cuestionan y se disponga la devolución de las sumas percibidas indebidamente, así como todo concepto cobrado en exceso de lo dispuesto en las Comunicaciones del BCRA, con más los intereses establecidos en las Normas PUSF; (v) se condene al Banco por el incumplimiento en el deber de información; y (vi) se aplique el daño punitivo previsto en el art. 52 de la LDC, para cada uno de los usuarios afectados. Se hace saber la existencia de las presentes actuaciones a fin de que, los clientes o ex clientes de Banco Patagonia S.A, que se consideren afectados, comparezcan a la causa a ejercer el derecho de exclusión previsto en el art. 54 L.D.C. dentro del plazo de sesenta (60) días corridos a partir del último día de publicación de edictos en el Boletín Oficial de la República Argentina. En caso de optar por ejercer el derecho deberán presentar una nota simple en el Tribunal, sin asistencia letrada. Asimismo, se informa que su silencio será considerado como manifestación de voluntad de ser incluidos en los efectos de la sentencia que se dicte. Por último, se invita a las Asociaciones de Consumidores y Usuarios a participar del procedimiento y denunciar ante el Juzgado la existencia de otro proceso de igual entidad al presente, con el objeto de adoptar las medidas ordenatorias correspondientes.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div>
                        <!-- Acuerdo en acción colectiva por Ingreso Familiar de Emergencia (I.F.E.) -->
                        <!-- botón -->
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <a href="#aacife" data-toggle="modal" class="btn-lnk-block">
                                    <h3>Acuerdo en acción colectiva por Ingreso Familiar de Emergencia (I.F.E.)</h3>
                                    <i class="icon icon-more"></i>
                                </a>
                            </div>
                        </div>
                        <!-- modal -->
                        <div class="modal fade" id="aacife">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <h2>Acuerdo en acción colectiva por Ingreso Familiar de Emergencia (I.F.E.)</h2>
                                        <p>En atención al acuerdo conciliatorio arribado en los autos caratulados &ldquo;ASOCIACIÓN CIVIL USUARIOS Y CONSUMIDORES UNIDOS c/ BANCO PATAGONIA S.A. s/ ORDINARIO&rdquo; (Nº 6912/2020) que tramita en el Juzgado Nacional de Primera Instancia en lo Comercial Nº 30, a cargo del Dr. Sebastián I. Sánchez Cannavó, en la Secretaría N° 59, se pone en conocimiento de aquellos clientes y exclientes que hubieran percibido el IFE por medio del Banco Patagonia, que en las presentes actuaciones se ha llegado a un acuerdo que implica: i) Restitución de los débitos que se hubieran efectuado sobre las sumas acreditadas en cuenta en concepto de IFE, siempre que no hubieran sido restituidas por el Banco con anterioridad; ii) Pago de intereses calculados a la tasa activa del Banco de la Nación Argentina para operaciones de descuento de documentos de terceros desde el 20/4/2020 para los Usuarios Beneficiarios con ingresos afectados del primer IFE y desde el 22/6/2020 para los Usuarios Beneficiarios con ingresos afectados del segundo IFE hasta la fecha de devolución de los importes debitados al IFE (en adelante Base IFE a Devolver); iii) Pago de intereses calculados a la tasa activa del Banco de la Nación Argentina para operaciones de descuento de documentos de terceros a 30 días hasta la fecha de pago de la Base IFE a Devolver; iv) Pago de una bonificación adicional del 25% de la Base IFE a Devolver debidamente actualizada. Los clientes con cuenta activa en el Banco percibirán el monto del acuerdo por medio de acreditación en cuenta, los exclientes que no tengan una cuenta activa en el Banco Patagonia, percibirán su crédito en una cuenta que eventualmente informe Coelsa o, en su defecto, deberán presentarse en una sucursal acreditando identidad y podrán percibir por ventanilla el importe que les corresponda o bien indicar los datos de una cuenta bancaria de su titularidad a la cual pueda ser transferido. El plazo establecido para el pago es de (un) 1 año contado desde la última publicación de edictos en el Boletín Oficial (Período de Pago). Vencido dicho plazo las sumas remanentes serán transferidas a las entidades de bien público y sin fines de lucro que se indican en el acuerdo. Las sumas que se acrediten en cuentas de Clientes gozarán del sistema de Reserva de Fondos, el que estará vigente hasta el fin del Período de Pago fecha en la que dejará de funcionar el sistema de Reserva de Fondos para sumas provenientes del IFE. Los clientes o exclientes podrán manifestar su voluntad de apartarse de los términos del presente acuerdo comunicándolo en el expediente, conforme lo establece el art. 54 de la ley 24.240. dentro de los dentro de los 40 días corridos desde la publicación del edicto en el Boletín Oficial. La solicitud de exclusión podrá ser efectuada mediante presentación en el expediente o por correo electrónico dirigido a <a href="mailto:jncomercial30.sec59@pjn.gov.ar">jncomercial30.sec59@pjn.gov.ar</a>. No requerirá patrocinio jurídico o fundamentación, ni será sustanciada.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					<!--
					<div>
                        !-- Acuerdo en acción colectiva por Impuesto Pais respecto de servicios digitales consumidos en el exterior --
                        !-- botón --
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <a href="#ipsge" data-toggle="modal" class="btn-lnk-block">
                                    <h3>Acuerdo en acción colectiva por Impuesto Pais respecto de servicios digitales consumidos en el exterior</h3>
                                    <i class="icon icon-more"></i>
                                </a>
                            </div>
                        </div>
                        !-- modal --
                        <div class="modal fade" id="ipsge">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <h2>Acuerdo en acción colectiva por Impuesto Pais respecto de servicios digitales consumidos en el exterior</h2>
                                        <p>En atención al acuerdo conciliatorio arribado en los autos caratulados “PROTEGIENDO AL CONSUMIDOR (P.A.C.) c/BANCO PATAGONIA S.A. S/REPETICIÓN DE SUMAS DE DINERO” (Expte. 129010), en trámite por ante el Juzgado de Primera Instancia en lo Civil y Comercial N° 7, Secretaría única de la Ciudad de Mar del Plata, se pone en conocimiento de los clientes de tarjeta de crédito de las sucursales de Banco Patagonia radicadas en la Provincia de Buenos Aires, que en caso que se hubiera registrado alguna diferencia en la alícuota cobrada por medio de débito en tarjeta de crédito del denominado Impuesto País respecto de los servicios digitales consumidos en el exterior hasta el día de la fecha. Podrán presentarse ante cualquier sucursal del Banco Patagonia ubicada en la Provincia de Buenos Aires para gestionar la restitución de dicha diferencia. La que será restituida por medio de acreditación en la tarjeta de crédito o por el medio que el cliente indique. En el caso de clientes que posean deudas con el Banco, las sumas a devolver serán previamente compensadas total o parcialmente con las adeudadas.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					-->
					<!--
                    <div>
                        !-- Acuerdo en acción colectiva por Exceso al acuerdo en cuenta corriente --
                        !-- botón --
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <a href="#eacc" data-toggle="modal" class="btn-lnk-block">
                                    <h3>Acuerdo en acción colectiva por Exceso al acuerdo en cuenta corriente</h3>
                                    <i class="icon icon-more"></i>
                                </a>
                            </div>
                        </div>
                        !-- modal --
                        <div class="modal fade" id="eacc">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <h2>Acuerdo en acción colectiva por Exceso al acuerdo en cuenta corriente</h2>
                                        <p>En atención al acuerdo conciliatorio arribado en los autos caratulados “PROTEGIENDO AL CONSUMIDOR (P.A.C.) c/BANCO PATAGONIA S.A. S/REPETICIÓN DE SUMAS DE DINERO” (Expte. 25036), en trámite por ante el Juzgado de Primera Instancia en lo Civil y Comercial N° 14, Secretaría única de la Ciudad de Mar del Plata, se pone en conocimiento de los clientes del segmento Personas titulares de cuenta corriente de las sucursales del Banco Patagonia de la Provincia de Buenos Aires exclusivamente, a los que se les hubiera cobrado el concepto “Comisión por exceso” o bien “Exceso al acuerdo” en cuenta corriente, desde el 2/3/2019 hasta la actualidad. Que podrán presentarse ante cualquier sucursal del Banco Patagonia ubicada en la Provincia de Buenos Aires para gestionar la restitución del importe cobrado por dicho concepto. Los cobros inferiores a $1.000.- podrán efectuarse por caja y los importes superiores a $1.000.- podrán efectuarse por caja o mediante transferencia a la cuenta que indique el cliente. En el caso de clientes que posean deudas con el Banco, las sumas a devolver serán previamente compensadas total o parcialmente con las adeudadas. Los usuarios que no deseen estar comprendidos en el presente acuerdo podrán manifestar su voluntad de apartarse de la solución adoptada en los términos del art. 54 de la Ley 24.240 sin necesidad de expresar la causa.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					-->
                    <!-- -->
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="alta-productos-personas-humanas.php" class="btn-lnk-block">
								<h3>Formularios de Alta de Productos para Personas Humanas</h3>
								<i class="icon icon-more"></i>
							</a>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="pdf/Carteleria_mod_HB.pdf" target="_blank" class="btn-lnk-block">
								<h3>Responsable de Atención al Cliente</h3>
								<i class="icon icon-pdf"></i>
							</a>
						</div>
					</div>
					<p>Te recordamos que para revocar la aceptación de tu/s producto/s o rescindir la relación contractual con nuestra entidad, podrás dirigirte a cualquiera de nuestras sucursales o ingresar a Patagonia e-bank con tu clave personal.</p>
					<div class="row">
                    	<!-- -->
						<div class="col-md-2 col-sm-2 col-xs-12">
							<a href="#atencion" data-toggle="modal">
							<img src="images/uf-afiche-atencion.png" width="270" class="img-responsive" alt=""/>
							</a>
							<!-- MODAL -->
							<div class="modal fade" id="atencion">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
										</div>
										<div class="modal-body">
											<p align="center"><img src="images/uf-afiche-xl-atencion.png" class="img-responsive" width="400" alt=""/></p>
										</div>
									</div>
								</div>
							</div>
							<!-- FIN MODAL -->
						</div>
                        <!-- -->
                        <div class="col-md-2 col-sm-2 col-xs-12">
							<a href="#baja" data-toggle="modal">
							<img src="images/uf-afiche-baja.png" width="270" class="img-responsive" alt=""/>
							</a>
							<!-- MODAL -->
							<div class="modal fade" id="baja">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
										</div>
										<div class="modal-body">
											<p align="center"><img src="images/uf-afiche-xl-baja.png" class="img-responsive" width="400" alt=""/></p>
										</div>
									</div>
								</div>
							</div>
							<!-- FIN MODAL -->
						</div>
                        <!-- -->
						<div class="col-md-2 col-sm-2 col-xs-12">
							<a href="#consultas" data-toggle="modal">
							<img src="images/uf-afiche-consultas-o-reclamos.png" width="270" class="img-responsive" alt=""/>
							</a>
							<!-- MODAL -->
							<div class="modal fade" id="consultas">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
										</div>
										<div class="modal-body">
											<p align="center"><img src="images/uf-afiche-xl-consultas-o-reclamos.png" class="img-responsive" width="400" alt=""/></p>
										</div>
									</div>
								</div>
							</div>
							<!-- FIN MODAL -->
						</div>
                        <!-- -->
						<div class="col-md-2 col-sm-2 col-xs-12">
							<a href="#contactate" data-toggle="modal">
							<img src="images/uf-afiche-contactate.png" width="270" class="img-responsive" alt=""/>
							</a>
							<!-- MODAL -->
							<div class="modal fade" id="contactate">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
										</div>
										<div class="modal-body">
											<p align="center"><img src="images/uf-afiche-xl-contactate.png" class="img-responsive" width="400" alt=""/></p>
										</div>
									</div>
								</div>
							</div>
							<!-- FIN MODAL -->
						</div>
                        <!-- -->
						<div class="col-md-2 col-sm-2 col-xs-12">
							<a href="#sino" data-toggle="modal">
							<img src="images/uf-afiche-si-no.png" width="270" class="img-responsive" alt=""/>
							</a>
							<!-- MODAL -->
							<div class="modal fade" id="sino">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
										</div>
										<div class="modal-body">
											<p align="center"><img src="images/uf-afiche-xl-si-no.png" class="img-responsive" width="400" alt=""/></p>
										</div>
									</div>
								</div>
							</div>
							<!-- FIN MODAL -->
						</div>
                        <!-- -->
						<div class="col-md-2 col-sm-2 col-xs-12">
							<a href="#CGU" data-toggle="modal">
							<img src="images/uf-afiche-cgu.png" width="270" class="img-responsive" alt=""/>
							</a>
							<!-- MODAL -->
							<div class="modal fade" id="CGU">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
										</div>
										<div class="modal-body">
											<p align="center"><img src="images/uf-afiche-xl-cgu.png" class="img-responsive" width="400" alt=""/></p>
										</div>
									</div>
								</div>
							</div>
							<!-- FIN MODAL -->
						</div>
                        <!-- -->
                        <div class="clearfix visible-lg-block visible-md-block visible-sm-block"></div>
                        <!-- -->
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<div class="cta-bar">
                        	<!-- -->
							<a class="cta-btn-big pop-desk" href="javascript:popMonedaExtranjera()">COTIZACIÓN DE MONEDA EXTRANJERA</a>
							<a class="cta-btn-big pop-port" href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/cotizacionMonedaExtranjera.htm" target="_blank">COTIZACIÓN DE MONEDA EXTRANJERA</a>
                            <!-- -->
						</div>
						<p>&nbsp;</p>
					</div>
				</div>
				<!-- PRE FOOTER -->
				<div class="row consulta">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<h4>Solicitalo en</h4>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12">
						<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="lnk">PATAGONIA E-BANK</a>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12">
						<a href="tel:0800-777-8500" class="lnk lnk-2-lines phone">Telefónicamente<br><span>0800-777-8500</span></a>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12">
						<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" class="lnk last">EN LA SUCURSAL</a>
					</div>
				</div>
				<!-- FIN PRE FOOTER -->
			</div>
		</div>
	</section>
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../assets/js/jquery-3.5.1.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/slick/slick.min.js"></script>
<script src="../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>