<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="0">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Banco Patagonia</title>
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon"/>
<link href="../../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->        <!-- SLIDES RESPONSIVE -->
        <style>
            /* DSK */
            #head-interfacturas {background-image: url(../../empresas/servicios/images/head-interfacturas-dsk.jpg)}

            @media screen and (max-width: 1200px) {
                /* TBT */
                #head-interfacturas {background-image: url(../../empresas/servicios/images/head-interfacturas-tbl.jpg); background-size: auto !important ;}
            }
            @media screen and (max-width: 560px) {
                /* MBL */
                #head-interfacturas {background-image: url(../../empresas/servicios/images/head-interfacturas-mbl.jpg)}
            }
        </style>
        <!-- -->
	</head>
<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                								<li><a href="../../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../../personas/index.php" class="">PERSONAS</a></li>
								<li><a href="../../nyps/index.php" class="">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../index.php" class="active">PYME</a></li>
								<li><a href="../../agro/index.php" class="">AGRO</a></li>
								<li><a href="../../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankempresas.bancopatagonia.com.ar/desktop-webserver/sso" target="_blank" class="patagonia-ebank-empresas">Patagonia e-Bank Empresas</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
						                        
                                                
                        						<!-- PYME -->
						<li class="nav-item"><a href="#" class="nav-lnk ">CUENTAS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
								<li><a href="../cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                                <!--
								<li><a href="../cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
								<li><a href="../cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
								<li><a href="../cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                                -->
                                <!--<li><a href="../cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                                <li><a href="../cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
								<li><a href="../cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA SUELDO</a>
							<ul class="list-unstyled submenu">
								<li><a href="../patagonia-sueldo/servicios.php">Servicios</a></li>
								<li><a href="../patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
								<li><a href="../patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
							</ul>
						</li>						
						<li class="nav-item"><a href="#" class="nav-lnk ">COMERCIO EXTERIOR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
								<li><a href="../comercio-exterior/productos.php">Productos</a></li>
								<li><a href="../comercio-exterior/otros-servicios.php">Servicios</a></li>
								<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                                <li><a href="../comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
								<li><a href="../comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
							</ul>
						</li>						
						<li class="nav-item"><a href="#" class="nav-lnk ">FINANCIACIÓN</a>
							<ul class="list-unstyled submenu">
								<li><a href="../financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
								<li><a href="../financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
								<li><a href="../financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
							</ul>
						</li>
                        <li class="nav-item"><a href="#" class="nav-lnk ">SEGUROS</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">INVERSIONES</a>
							<ul class="list-unstyled submenu">
								<li><a href="../inversiones/plazo-fijo.php">Plazo Fijo</a></li>
								<li><a href="../inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
								<li><a href="../inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
							</ul>
						</li>						
						<li class="nav-item"><a href="#" class="nav-lnk active">SERVICIOS</a>
							<ul class="list-unstyled submenu">
								<li><a href="../oficina-virtual-cobranzas.php">Oficina virtual de Cobros</a></li>
								<li><a href="recaudaciones.php">Recaudaciones</a></li>
								<li><a href="pagos.php">Pagos</a></li>
								<li><a href="tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
								<li><a href="comercios-patagonia.php">Comercios Patagonia</a></li>
                                <li><a href="pago-de-servicios.php">Pago de Servicios</a></li>
								<li><a href="interbanking.php">Interbanking</a></li>
								<li><a href="interfacturas.php">Interfacturas</a></li>
								<li><a href="pagos-afip.php">Pagos AFIP</a></li>
								<li><a href="wapa.php">WAPA</a></li>
							</ul>
						</li>
						<!-- FIN PYME -->
						                        
                        						
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../personas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
						<li><a href="https://ahorrosybeneficios.bancopatagonia.com.ar/ahorrosybeneficios/" target="_blank">Beneficios</a></li>
                        <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/cajas-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../../personas/inversiones/index.php">Inversiones</a></li>
                        <li><a href="../../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
						<li><a href="../../personas/plan-sueldo/index.php">Patagonia Sueldo</a></li>
						<li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../../personas/inversiones/index.php">Inversiones</a></li>
                        <li><a href="../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../../personas/productos-y-servicios/cajas-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../index.php" class="active">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu active">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../oficina-virtual-cobranzas.php">Oficina virtual de Cobros</a></li>
						<li><a href="recaudaciones.php">Recaudaciones</a></li>
						<li><a href="pagos.php">Pagos</a></li>
						<li><a href="tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="interbanking.php">Interbanking</a></li>
						<li><a href="interfacturas.php">Interfacturas</a></li>
						<li><a href="pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/oficina-virtual-cobranzas.php">Oficina virtual de Cobros</a></li>
                        <li><a href="../../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/oficina-virtual-cobranzas.php">Oficina virtual de Cobros</a></li>
						<li><a href="../../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        		<li class="nav-main-item"><a href="../../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<section class="sec-head">
        <div class="sec-pic-head" id="head-interfacturas">
        </div>
        <!--
		<div class="sec-pic-head" style="background-image: url(../../empresas/comercio-exterior/images/head-factura-electronica.jpg);">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-sm-6 col-xs-12 sec-pic-area">
						<div class="sec-head-card">
							<h2 class="with-border">Interfacturas</h2>
							<p>Suscribite y optimizá la gestión de tus facturas electrónicas.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
        -->
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="../index.php">PyME</a></li>
					<li>Servicios</li>
					<li class="active">Interfacturas</li>
				</ol>
			</div>
		</div>
	</section>
	<section class="container">
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="text-data">
				<p>Es la solución de Interbanking para la emisión y recepción de Facturas Electrónicas que permite la visualización de las facturas en forma centralizada y la integración con los sistemas
					contables de la compañía por medio de un formato estándar.</p>
				<p>Sean o no alcanzadas por las resoluciones de AFIP, con Interfacturas las empresas Simplifican su sistema de facturación, obteniendo información detallada e integrándolo a los
					sistemas de gestión por medio de un formato estándar.</p>
				<hr>
				<h3>Beneficios de operar con Interfacturas</h3>
				<ul>
					<li>Reducir Costos (*)</li>
					<li>Optimizar Procesos</li>
					<li>Integrar la facturación a los sistemas contables</li>
					<li>Ahorrar tiempo y espacio</li>
					<li>Centralizar la emisión y recepción</li>
					<li>Realizar seguimiento online</li>
					<li>Cuidar el medio ambiente</li>
				</ul>
				<p>(*) Costos: Solo se cobra por factura emitida. No fee mensual, no licencias, no costo de implementación.</p>
				<hr>
				<h3>Exportadores</h3>
				<p><strong>Sujetos Obligados:</strong> exportadores inscriptos en los Registros especiales Aduaneros</p>
				<p><strong>Fechas de la incorporación:</strong></p>
				<ul>
					<li>01-05-10: grandes operadores. Empresas que exportan por más de U$S 100.000.000 al año, o realicen más de 1.000 operaciones año. (RG 596/99).</li>
					<li>01-07-10: Resto de los operadores.</li>
					<li>Operaciones de Removido oficializadas en el SIM a partir del 01-10-10 bajo el subrégimen "REMO" Guía de Removido (R.G.1229/2002) deberán presentar factura electrónica de
						exportación si se encuentran en el supuesto establecido en la R.G. 2758/2010 ("REMO" con destino al Área Aduanera Especial).</li>
				</ul>
				<p><strong>Comprobantes alcanzados:</strong> Factura E, Nota de Crédito E y Nota de Débito E</p>
				<p><strong>Operaciones alcanzadas:</strong> Exportaciones a consumo de Bienes</p>
                
                <p style="text-align:center">SUBREGÍMENES</p>
                
				<table class="table table-bordered">
					<tr>
					  <td width="20%">EC01</td>
					  <td width="60%">EXPORTACIÓN A CONSUMO</td>
						<td width="20%">EXPCON</td>
					</tr>
					<tr>
						<td>EC03</td>
						<td>EXPORTACIÓN A CONSUMO C/DIT CON TRANSFORMACIÓN</td>
						<td>EXPCON</td>
					</tr>
					<tr>
					  <td>EC04</td>
					  <td>EXPORT. A CONS. C/DIT INGRES. P/ TRANSF. EGRESADO S/TRANSF</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>EC05</td>
					  <td>EXPORTACIÓN A CONSUMO DE EXPORT. TEMP. C/TRANSFORMACIÓN</td>
					  <td>EXPCONS</td>
				  </tr>
					<tr>
					  <td>EC06</td>
					  <td>EXPORTACIÓN A CONSUMO DE EXPORT. TEMPORAL S/ TRANSFORM</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>EC07</td>
					  <td>EXPORTACIÓN A CONSUMO DE MERCADERIA EN CONSIGNACIÓN</td>
					  <td>EXPCONS</td>
				  </tr>
					<tr>
					  <td>EC09</td>
					  <td>EXPORTACIÓN A CONSUMO DE CONCENTRADO DE MINERALES</td>
					  <td>EXPCONS</td>
				  </tr>
					<tr>
					  <td>EC16</td>
					  <td>EXPORTACIÓN A CONSUMO RESIDUOS DE IMPORT. TEMPO. CON/TRANS</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>EC18</td>
					  <td>EXPORTACIÓN A CONSUMO DESDE ZONA FRANCA AL EXTERIOR</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>EC19</td>
					  <td>EXPORTACIÓN A CONSUMO CON CANC. DE INSUMO INGR. TEMP. A 2F</td>
					  <td>EXPCONS</td>
				  </tr>
					<tr>
					  <td>ECE1</td>
					  <td>EGRESO DEL AAE A CONS EN EXT. C/TRANS. TERRES. POR TNC</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>ECR1</td>
					  <td>EXPORTACIÓN A CONSUMO DE BIENES TRANSFORMADOS RAF</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>ECR2</td>
					  <td>EGRESO DE MERCADERÍA S/TRANSF. POR VENTA AL EXTERIOR</td>
					  <td>REEMBARCO</td>
				  </tr>
					<tr>
					  <td>EG01</td>
					  <td>EXPORTACIÓN A CONSUMO GRAN OPERADOR</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>EG03</td>
					  <td>EXPORTACIÓN A CONSUMO C/DIT CON TRANS. GRAN OPERADOR</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>EG05</td>
					  <td>EXPORTACIÓN A CONSUMO DE EXP. TEMP. C/TRANSF. P/ GRAN OPERADOR</td>
					  <td>EXPCONS</td>
				  </tr>
					<tr>
					  <td>EG06</td>
					  <td>EXPORTACIÓN A CONSUMO DE EXP. TEMP. S/TRANSF. P/ GRAN OPERADOR</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>EG07</td>
					  <td>EXPORTACIÓN A CONSUMO DE MERC. EN CONSIG. P/GRAN OPERADOR</td>
					  <td>EXPCONS</td>
				  </tr>
					<tr>
					  <td>EG13</td>
					  <td>EXPORTACIÓN A CONSUMO C/DIT C/T GOP CON AUTORIZACIÓN</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>ER01</td>
					  <td>RANCHO PARA MEDIOS DE TRANSPORTE DE BANDERA EXTRANJERA</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>ER02</td>
					  <td>RANCHO PARA MEDIOS DE TRANSPORTE DE BANDERA NACIONAL</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>ES02</td>
					  <td>EXPORTACIÓN DE MERCADERIAS CON PRECIOS REVISABLES</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>RE01</td>
					  <td>REEMBARCO SIN DOCUMENTO DE TRANSPORTE (*)</td>
					  <td>REEMBARCO</td>
				  </tr>
					<tr>
					  <td>RE04</td>
					  <td>REEMBARCO CON DOCUMENTO DE TRANSPORTE (*)</td>
					  <td>REEMBARCO</td>
				  </tr>
					<tr>
					  <td>RE05</td>
					  <td>REEMBARCO CON DOCUMENTO DE TRANSPORTE DAP (*)</td>
					  <td>REEMBARCO</td>
				  </tr>
					<tr>
					  <td>RE06</td>
					  <td>REEMBARCO SOBRE DESTINACIÓN SUSP. DE ALMACENAMIENTO (*)</td>
					  <td>REEMBARCO</td>
				  </tr>
					<tr>
					  <td>REMO</td>
					  <td>GUIA DE REMOVIDO (**)</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>ZFE2</td>
					  <td>EG. POR AEROPUERTO / PUERTO DE LA ZF EN EL MISMO ESTADO AL EXT. </td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>ZFE4</td>
					  <td>EGR ZF DE UN PROD. DE PROC. PRODUCT. O REPARACION AL EXT.</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>ZFE6</td>
					  <td>EGR ZF DE UN RESIDUO DE PROCESO PROD. C/ VALOR COM. AL EXT.</td>
					  <td>EXPCON</td>
				  </tr>
					<tr>
					  <td>ZFRE</td>
					  <td>REEMBARCO POR AEROPUERTO / PUERTO DE LA ZF MISMO ESTADO (*)</td>
					  <td>REEMBARCO</td>
				  </tr>
				</table> <br>
                <p>REFERENCIAS</p> <br>
                <p>(*)Sólo si hay una venta al exterior</p>
                <p>(*)Sólo si la operación se realiza al Area Aduanera Especial, en el marco de lo dispuesto por la Resolucíon General N° 1229 y sus modificatorias.</p> <br> <br>
                
                <hr>                
				<h3>Importadores</h3>
				<p><strong>Sujetos Obligados:</strong></p>
				<ul>
					<li>Responsables Inscriptos en el IVA</li>
					<li>Comprendidos por el Apartado 1 del artículo 91 de la Ley N° 22.415 y sus modificaciones -Código Aduanero-</li>
					<li>Inscriptos en los “Registros especiales Aduaneros” previstos en el Título II de la R.G. 2.571, sus modificaciones y su complementaria</li>
					<li>Que realicen importación de bienes.</li>
				</ul>
				<p><strong>Excepciones:</strong></p>
				<ul>
					<li>Los responsables notificados conforme el Artículo 2° de la R.G. N° 2.904</li>
					<li>Los sujetos que realicen solo importaciones de bienes de uso y/o insumos o materiales destinados a su mantenimiento</li>
					<li>Disposiciones del R.G. 1361</li>
					<li>Demás excepciones previstas en la R.G. 2485</li>
				</ul>
				<p><strong>Fechas de la incorporación:</strong></p>
				<ul>
					<li>Abril 2011</li>
				</ul>
				<p><strong>Comprobantes alcanzados:</strong></p>
				<ul>
					<li>Facturas, Notas de Crédito y Notas de Débito; clase “A”</li>
					<li>Facturas, Notas de Crédito y Notas de Débito; clase “B”</li>
				</ul>
				<p><strong>Excepciones:</strong></p>
				<ul>
					<li>Operaciones alcanzadas por controladores fiscales</li>
					<li>Venta por “ruteo”</li>
				</ul>
				<hr>
				<h3>Si soy emisor de facturas electrónicas</h3>
				<p><strong>¿Cómo emito Facturas Electrónicas?</strong></p>
				<p>La Emisión de Facturas Electrónicas puede realizarse en lote o en unidad, dependiendo del tipo de comprobante, a través del sitio Interfacturas.</p>
				<p><strong>¿Por cuánto tiempo podré encontrar las facturas disponibles en la red para su visualización?</strong></p>
				<p>El servicio de red de visualización de facturas electrónicas contempla que las mismas estén a disposición del usuario receptor desde la fecha de asignación del C.A.E. (Código de
					Autorización Electrónico) y hasta 90 días posteriores.</p>
				<p><strong>¿Puedo saber si las facturas que emití fueron visualizadas?</strong></p>
				<p>Entre las ventajas que ofrece el servicio de Interfacturas se encuentra la función de “TIME-STAMP”, es decir el registro con indicación de fecha, hora en que el receptor de la factura
					ingresó al servicio y visualizó los comprobantes.</p>
				<p><strong> Previo a la suscripción a Interfacturas deberás:</strong></p>
				<ol>
					<li>Analizar con tu asesor contable si vos o tu empresa están alcanzados por las Resoluciones Generales AFIP 2485, 2511, 1361, 2557, 2758, 2757,2959 y si cumplen con los
						requisitos previstos. Si no estuvieras comprendido dentro de los rubros obligados podés optar voluntariamente por este sistema de facturación.</li>
					<li>Generar la Información de facturación en el formato xml provisto por Interbanking y poder decodificar en el mismo formato los archivos de rendición</li>
					<li>Efectuar los siguientes trámites en AFIP con un usuario que tenga clave fiscal nivel 3:</li>
				</ol>
				<p> - Realizar el empadronamiento ante AFIP para ingresar al régimen de Factura Electrónica.<br>
					- Delegar en Interbanking la operatoria de gestión del Código de Autorización Electrónica (CAE). El servicio que tiene que seleccionar es: “ARFE- Gestionar Relaciones”. </p>
				<p>Para adherirte a Interfacturas a través de Banco Patagonia:</p>
				<p>- Ingresá a www.interfacturas.com.ar , completá el formulario electrónico, consignando CBU de tu cuenta en Banco Patagonia. Deberás aceptar los términos y condiciones.<br>
					- Imprimí los formularios de adhesión generados en el sitio de Interfacturas, firmalos y entregalos en tu sucursal de Banco Patagonia<br>
					- Informá a tus clientes usuarios de Interbaking que podrán visualizar las facturas disponibles a través de cualquiera de los servicios disponibles de la red.</p>
				<p> Los clientes que aun no utilizan los servicios de Interbanking pueden suscribirse como visualizadores sin ningún costo adicional.</p>
				<hr>
				<h3>Si soy receptor de facturas electrónicas</h3>
				<p><strong>¿Cómo realizo la consulta de las facturas? ¿La visualización y descarga de las mismas se lleva a cabo de forma individual o por la totalidad de las recibidas?</strong></p>
				<p>Podés realizar la consulta de la totalidad de las facturas emitidas, en un periodo determinado, concretando la visualización, impresión y/o descarga en formato XML, en forma<br>
					individual. Para el receptor es gratuito el servicio de visualización.</p>
				<p><strong> Para adherirse a Interfacturas a través de Banco Patagonia:</strong></p>
				<ol>
					<li>Ingresá a www.interfacturas.com.ar y completá el formulario electrónico, consignando CBU de su cuenta en Banco Patagonia. Deberás aceptar los términos y condiciones.</li>
					<li>Imprimí los formularios de adhesión generados en el sitio de interfacturas, firmalos y entregalos en tu sucursal de Banco Patagonia</li>
				</ol>
				<hr>
				<h3>Sujetos Obligados</h3>
				<ul>
					<li><strong>Agencias de Turismo – ENERO.</strong></li>
					<li><strong>Importadores de Bienes y Servicios ABRIL.</strong></li>
					<li>Operadores de TV por cable y satelital.</li>
					<li>Telefonía móvil y satelital.</li>
					<li>Empresas de limpieza.</li>
					<li>Servicios de vigilancia.</li>
					<li>Transportadoras de caudales.</li>
					<li>Bienes de Capital, de informática y telecomunicaciones que utilizan bono fiscal.</li>
					<li>Seguros de caución.</li>
					<li>Presentación de Servicios de Publicidad y Conexos.</li>
					<li>Servicios de Peaje.</li>
					<li>Servicios de informática</li>
					<li>Desarrolladores de Software.</li>
					<li>Servicios profesionales prestados (Facturación anual igual o mayor a $ 600 mil).</li>
					<li>Compraventa de cosas muebles, locaciones y prestaciones de servicios, locaciones de cosas y de obras y de las señas o anticipos que congelen precios, efectuadas en el mercado<br>
						interno, que reciban la comunicación fehaciente de AFIP.</li>
					<li>Exportadores: Facturas, Notas de Crédito y Débito E.</li>
					<li>Proveedores del Estado.</li>
					<li>Agencias de Turismo.</li>
				</ul>
				<hr>
				<h3>Próximas Obligatoriedades</h3>
				<ul>
					<li><strong>Importadores de Bienes y Servicios ABRIL.</strong></li>
					<li><strong>Titulares de proyectos que están alcanzados por los Regímenes Regionales de Promoción Industrial y Promoción Agropecuaria en La Rioja, San Luis, Catamarca, San
						Juan y Mendoza, previstos por las leyes Nº 22.021, 22.702 y 22.973. MAYO</strong></li>
					<li>Industria Higiene y Tocador.</li>
					<li>Engordadores de ganado bovino a corral (Feedlots 2.500 animales).</li>
					<li>Faenadores avícolas (Faena mensual de 2.000.000 de cabezas).</li>
					<li>Molinos (5 mil kilogramos por hora de molienda).</li>
					<li>Monotributistas – contribuyentes que se encuentren en los escalones superiores del monotributo.</li>
				</ul>
				<hr>
				<h3>Factura Electrónica - Preguntas Frecuentes</h3>
				<p><strong>¿Qué es factura electrónica?</strong><br>
					También llamada e-factura o comprobante fiscal digital, es un documento electrónico que cumple con los requisitos legal y reglamentariamente exigibles a las facturas tradicionales
					garantizando, entre otras cosas, la autenticidad de su origen y la integridad de su contenido a través de la asignación del CAE otorgado por la AFIP.</p>
				<p><strong>¿Cómo adquiere validez la factura electrónica?</strong><br>
					A través del C.A.E. (Código de Autorización Electrónico) que es el código de autorización electrónico, que otorga la AFIP a cada documento Un documento con C.A.E. indica que fue
					autorizado por la AFIP.</p>
				<p>A través de InterFacturas no tiene que preocuparse por realizar la gestión de C.A.E. ya que se realiza en forma automática.</p>
				<p><strong>¿Cuáles son las características de los comprobantes electrónicos?</strong></p>
				<ul>
					<li>Poseen efectos fiscales frente a terceros si el documento electrónico contiene el Código de Autorización Electrónico “CAE”, asignado por la AFIP.</li>
					<li>Son identificados con un punto de venta específico, distinto a los utilizados para la emisión de comprobantes manuales o a través de controlador fiscal.</li>
				</ul>
				<p>Fuente: Art.9 RG 2485/08</p>
				<p><strong>¿En qué plazo debe ser puesta a disposición la factura electrónica?</strong><br>
					Dentro de los 10 días corridos contados desde la asignación del “C.A.E.”.</p>
				<p>Fuente: Art.30 RG 2485/08</p>
			</div>
			<!-- PRE FOOTER -->
			<div class="row consulta">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<h4>Solicitalo en</h4>
				</div>
				<div class="col-md-4 col-sm-4 col-xs-12">
					<a href="../../empresas/patagonia-ebank-empresas.php" target="_blank" class="lnk">PATAGONIA E-BANK</a>
				</div>
				<div class="col-md-4 col-sm-4 col-xs-12">
					<a href="tel:08109996655" class="lnk lnk-2-lines phone">Telefónicamente<br><span>0810 888 8500</span></a>
				</div>
				<div class="col-md-4 col-sm-4 col-xs-12">
					<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" class="lnk last">EN LA SUCURSAL</a>
				</div>
			</div>
			<!-- FIN PRE FOOTER -->
		</div>
	</div>
</section>	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../../assets/js/jquery-3.5.1.min.js"></script>
<script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../assets/js/slick/slick.min.js"></script>
<script src="../../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>