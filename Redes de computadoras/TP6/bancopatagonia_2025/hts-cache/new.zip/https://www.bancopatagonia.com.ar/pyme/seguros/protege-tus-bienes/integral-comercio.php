<!DOCTYPE html>
<html lang="es">
<head>
<!-- PAGINA A DESINDEXAR -->
<meta name="robots" content="noindex">
<script type="text/javascript">
window.location = "becas-estudiantiles.php";
</script>
</head>
<body>
</body>
</html>