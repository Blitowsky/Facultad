Holaa, ahí cree una nueva rama en la cual realice algunos cambios, si les parecen bien realizo el merge!
