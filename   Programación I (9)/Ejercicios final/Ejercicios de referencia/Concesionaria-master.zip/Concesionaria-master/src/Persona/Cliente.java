/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persona;

import Vehiculo.Vehiculo;

/**
 *
 * @author PROGRAMAR
 */
public class Cliente extends Persona {
    
    private boolean empresa;
    private int idCliente;
    
    public Cliente(String Nombre, String Apellido, int dni, boolean empresa, int idCliente) {
        super(Nombre, Apellido, dni);
        this.empresa = empresa;
        this.idCliente = idCliente;
    }
    
    
    //GETTERS
    public boolean getEmpresa(){
        return this.empresa;
    }
    
    public int getIdCliente(){
        return this.idCliente;
    }
    
    //SETTERS
    
    public void setEmpresa(boolean est){
        this.empresa = est;
    }
    
    public void setIdCliente(int idCliente){
        this.idCliente = idCliente;
    }
    
    //METODOS PROPIOS
    
    public Vehiculo comprarVehiculo(){
        System.out.println("COMPRAR VEHICULO");  
        return null;
    }
    
    public void ofrecerVenta(){
        System.out.println("ofrecer venta");
    }
    
    public void quejarse(){
        System.out.println("quejarse");
    }
     
    
    
    
    
}
