/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persona;

/**
 *
 * @author PROGRAMAR
 */
public class Limpieza extends Empleado {
    
    private String tipoLimpieza;
    private String materialLimpieza;
    
    public Limpieza(String Nombre, String Apellido, int dni, int añosExp, int sueldo, String tipo, String material) {
        super(Nombre, Apellido, dni, añosExp, sueldo);
        this.tipoLimpieza = tipo;
        this.materialLimpieza = material;
    }
    
    
    //GETTERS
    
    public String getTipoLimpieza(){
        return this.tipoLimpieza;
    }
    
    public String getMaterialLimpieza(){
        return this.materialLimpieza;
    }
    
    //SETTERS
    
    public void setTipoLimpieza(String tipo){
        this.tipoLimpieza = tipo;
    }
    
    public void setMaterialLimpieza(String material){
        this.materialLimpieza = material;
    }
    
    //METODOS PROPIOS
    
    public void limpiar(){
        System.out.println("LIMPIAR");
    }
}
