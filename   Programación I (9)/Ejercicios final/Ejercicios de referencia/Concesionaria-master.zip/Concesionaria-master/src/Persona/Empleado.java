/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persona;

/**
 *
 * @author PROGRAMAR
 */
public abstract class Empleado extends Persona {
    private int añosExperiencia;
    private int sueldo;
   
    
    public Empleado(String Nombre, String Apellido, int dni, int añosExp, int sueldo) {
        super(Nombre, Apellido, dni);
        this.añosExperiencia = añosExp;
        this.sueldo = sueldo;
    }
    
    //GETTERS
    
    public int getAñosExp(){
        return this.añosExperiencia;
    }
    
    public int getSueldo(){
        return this.sueldo;
    }
    
    
    
    //SETTERS
    
    public void setAñosExp(int años){
        this.añosExperiencia = años;
    }
    
    public void setSueldo(int sueldo){
        this.sueldo = sueldo;
    }
    
    //METODOS PROPIOS
    
    public void cobrarSueldo(){
        System.out.println("COBRAR SUELDO");
    }
    
    public void renunciar(){
        System.out.println("RENUNCIAR");
    }
    
}
