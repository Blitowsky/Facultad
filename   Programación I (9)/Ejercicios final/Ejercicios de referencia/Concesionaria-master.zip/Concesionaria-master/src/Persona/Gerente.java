/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persona;

/**
 *
 * @author PROGRAMAR
 */
public class Gerente extends Empleado {
    
    private int idGerente; 
    
    public Gerente(String Nombre, String Apellido, int dni, int añosExp, int sueldo, int id) {
        super(Nombre, Apellido, dni, añosExp, sueldo);
        this.idGerente = id;
    }
    
    //GETTERS
    
    public int getIdGerente(){
        return this.idGerente;
    }
    
    //SETTERS 
    
    public void setIdGerente(int id){
        this.idGerente = id;
    }
    
    //METODOS PROPIOS
    
    public Vendedor agregarVendedor(){
        return null;
    }
    
    public void gestionarFinanzas(){
        System.out.println("GESTIONAR FINANZAS");
    }
    
    public void pagarSueldos(){
        System.out.println("PAGAR SUELDOS");
    }
    
    public void agregarIngreso(){
        System.out.println("AGREGAR INGRESO");
    }
}
