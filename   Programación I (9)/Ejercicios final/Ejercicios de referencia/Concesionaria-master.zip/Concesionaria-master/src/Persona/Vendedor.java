/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persona;

import Vehiculo.Vehiculo;

/**
 *
 * @author PROGRAMAR
 */
public class Vendedor extends Empleado {
    
    private int cantVentas;
    private int idVendedor;
    private static int generadorId = 0;
    
    public Vendedor(String Nombre, String Apellido, int dni, int añosExp, int sueldo, int ventas) { // considero que los IDs deberíamos generarlos nosotros, int id)  {
        super(Nombre, Apellido, dni, añosExp, sueldo);
        this.cantVentas = ventas;
        this.idVendedor = generarId();
    }
    
    private int generarId() {
        return ++generadorId; 
    }
    
    //GETTERS
    
    public int getCantVentas(){
        return this.cantVentas;
    }
    
    public int getIdVendedor(){
        return this.idVendedor;
    }
    
    //SETTERS
    
    public void setCantVentas(int ventas){
        if(ventas > 0){
            this.cantVentas += ventas;
        }
        
    }
    
    //No creo que sea necesario settear el ID del vendedor porque se supone que es único
    public void setIdVendedor(int id){
        this.idVendedor = id;
    }
    
    
    //METODOS PROPIOS
    
    public void venderVehiculo(){
        System.out.println("VENDER VEHICULO");
    }
    
    public void publicarVehiculo(Vehiculo vehiculo){
        //En esta función debería poder agregarlo a la base de datos
        System.out.println("PUBLICAR VEHICULO");
    }
    
    public void mostrarVehiculo(Vehiculo vehiculo){
        //System.out.println(vehiculo.mostrarDatos);
    }
    
    public void agregarCliente(){
        System.out.println("AGREGAR CLIENTE");
    }
    
    public void recibirVehiculo(){
        System.out.println("RECIBIR VEHICULO");
    }
    
    public boolean revisarVehiculo(){
        System.out.println("REVISAR VEHICULO");
        return true;
    }
    
}
