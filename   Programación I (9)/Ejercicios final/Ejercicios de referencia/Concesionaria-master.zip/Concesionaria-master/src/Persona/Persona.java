/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persona;

/**
 *
 * @author PROGRAMAR
 */
public abstract class Persona {
    private String nombre;
    private String apellido;
    private int DNI;
    
    public Persona(String Nombre, String Apellido, int dni){
        this.nombre = Nombre;
        this.apellido = Apellido;
        this.DNI = dni;
    }
    
    
    //GETTERS
    public String getNombre(){
        return this.nombre;
    }
    
    public String getApellido(){
        return this.apellido;
    }
    
    public int getDNI(){
        return this.DNI;
    }
    
    
    //SETTERS
    
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    
    public void setApellido(String apellido){
        this.apellido = apellido;
    }
    
    public void setDNI(int dni){
        this.DNI = dni;
    }
    
    //METODOS PROPIOS
    
    public void respirar(){
        System.out.println("RESPIRAR");
    }
    
    public void caminar(){
        System.out.println("CAMINAR");
    }
    
    public void trabajar(){
        System.out.println("TRABAJAR");
    }
}
