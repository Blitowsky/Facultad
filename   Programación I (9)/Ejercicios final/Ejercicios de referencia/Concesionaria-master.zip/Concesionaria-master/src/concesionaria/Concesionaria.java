/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package concesionaria;

import java.util.ArrayList;

/**
 *
 * @author Andrea
 */
public class Concesionaria {
 
    private String nombre;
    private String apellido;
    private ArrayList listaClientes;
    private ArrayList listaEmpleados;
    private ArrayList listaVehiculos;

    public Concesionaria(String nombre, String apellido, ArrayList listaC, ArrayList listaE, ArrayList listaV){
        this.nombre = nombre;
        this.apellido = apellido;
        this.listaClientes = listaC;
        this.listaEmpleados = listaE;
        this.listaVehiculos = listaV;
    }
    
    //GETTERS

    public String getNombre(){
        return this.nombre;
    }

    public String getApellido(){
        return this.apellido;
    }

    public ArrayList getListaClientes(){
        return this.listaClientes;
    }

    public ArrayList getListaEmpleados(){
        return this.listaEmpleados;
    }

    public ArrayList getListaVehiculos(){
        return this.listaVehiculos;
    }

    //SETTERS

    public void setNombre(String Nombre){
        this.nombre = Nombre;
    }

    public void setApellido(String Apellido){
        this.apellido = Apellido;
    }

    public void setListaClientes(ArrayList listaClientes){
        this.listaClientes = listaClientes;
    }

    public void setListaEmpleados(ArrayList listaEmpleados){
        this.listaEmpleados = listaEmpleados;
    }

    public void setListaVehiculos(ArrayList listaVehiculos){
        this.listaVehiculos = listaVehiculos;
    }

    //METODOS PROPIOS

    public void contratarEmpleado(){
        System.out.println("CONTRATAR EMPLEADO");
    }

    public void despedirEmpleado(){
        System.out.println("DESPEDIR EMPLEADO");
    }

    public void mostrarListaVehiculos(){
        System.out.println("MOSTRAR LISTA DE VEHICULOS");
    }
    
}
