/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package concesionaria;

/**
 *
 * @author PROGRAMAR
 */
public class Finanzas {
    private int presupuesto;

    public Finanzas(int Presupuesto){
        this.presupuesto = Presupuesto;
    }


    //GETTER

    public int getPresupuesto(){
        return this.presupuesto;
    }

    //SETTER

    public void setPresupuesto(int plata){
        this.presupuesto = plata;
    }

    //METODOS PROPIOS

    public void mostrarBalance(){
        System.out.println("MOSTRAR BALANCE");
    }
}
