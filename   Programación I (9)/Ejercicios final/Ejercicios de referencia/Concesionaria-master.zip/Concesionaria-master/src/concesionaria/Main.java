/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package concesionaria;

import Persona.Vendedor;
import Vehiculo.Auto;
import java.util.ArrayList;
import views.principal;

/**
 *
 * @author PROGRAMAR
 */
public class Main {

    public static void main(String[] args) {
           /* EN ESTE CASO ESTOY PROBANDO QUE LOS IDS GENERADOS AUTOMÁTICAMNETE FUNCIONEN CORRECTAMENTE
            
           
           Auto auto1 = new Auto("Kwid 2018","Toyota","Blanco",0,"Nuevo",15,"Automático",25000,24);
           Auto auto2 = new Auto("Kwid 2018","Toyota","Blanco",0,"Nuevo",15,"Automático",25000,24);
           Auto auto3 = new Auto("Kwid 2018","Toyota","Blanco",0,"Nuevo",15,"Automático",25000,24);
           Auto auto4 = new Auto("Kwid 2018","Toyota","Blanco",0,"Nuevo",15,"Automático",25000,24);
           Auto auto5 = new Auto("Kwid 2018","Toyota","Blanco",0,"Nuevo",15,"Automático",25000,24);
           auto1.mostrarDatos();
           System.out.println("1: " + auto1.getIdVehiculo());
           System.out.println("2: " + auto2.getIdVehiculo());
           System.out.println("3: " + auto3.getIdVehiculo());
           System.out.println("4: " + auto4.getIdVehiculo());
           System.out.println("5: " + auto5.getIdVehiculo());
           auto2.getIdVehiculo();
           auto3.getIdVehiculo(); 
           Vendedor vendedor1 = new Vendedor("Juan", "Perez", 14123, 142, 142, 456);
           Vendedor vendedor2 = new Vendedor("Juan", "Perez", 14123, 142, 142, 456);
           Vendedor vendedor3 = new Vendedor("Juan", "Perez", 14123, 142, 142, 456);
           Vendedor vendedor4 = new Vendedor("Juan", "Perez", 14123, 142, 142, 456);
           System.out.println("1: " + vendedor1.getIdVendedor());
           System.out.println("2: " + vendedor2.getIdVendedor());
           System.out.println("3: " + vendedor3.getIdVendedor());
           System.out.println("4: " + vendedor4.getIdVendedor()); */
           
           
        principal ventana = new principal();
        ventana.setVisible(true);
        
    }



    
}
