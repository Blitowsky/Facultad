/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vehiculo;

/**
 *
 * @author PROGRAMAR
 */
public class Moto extends Vehiculo {
    private int cantPasajeros;
    private String tipoEmbrague;
    public Moto(String modelo, String marca, String color, int kilometros, String condicion, int potenciaMotor,
            String tipoVehiculo, int precio, int cantPasajeros, String tipoEmbrague) {
        super(modelo, marca, color, kilometros, condicion, potenciaMotor, tipoVehiculo, precio);
        this.cantPasajeros = cantPasajeros;
        this.tipoEmbrague = tipoEmbrague;
    }

    //SETTERS Y GETTERS
    public int getCantPasajeros() {
        return cantPasajeros;
    }
    public void setCantPasajeros(int cantPasajeros) {
        this.cantPasajeros = cantPasajeros;
    }
    public String getTipoEmbrague() {
        return tipoEmbrague;
    }
    public void setTipoEmbrague(String tipoEmbrague) {
        this.tipoEmbrague = tipoEmbrague;
    }

    
}
