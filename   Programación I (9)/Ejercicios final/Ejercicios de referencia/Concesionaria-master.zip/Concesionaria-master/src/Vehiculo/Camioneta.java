/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vehiculo;

/**
 *
 * @author PROGRAMAR
 */
public class Camioneta extends Vehiculo {
    private String tipoTraccion;

    public Camioneta(String modelo, String marca, String color, int kilometros, String condicion, int potenciaMotor,
            String tipoVehiculo, int precio, String tipoTraccion) {
        super(modelo, marca, color, kilometros, condicion, potenciaMotor, tipoVehiculo, precio);
        this.tipoTraccion = tipoTraccion;
    }


    //SETTERS Y GETTERS
    public String getTipoTraccion() {
        return this.tipoTraccion;
    }

    public void setTipoTraccion(String tipoTraccion) {
        this.tipoTraccion = tipoTraccion;
    }

    
}
