/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vehiculo;

/**
 *
 * @author PROGRAMAR
 */
public class Auto extends Vehiculo {
    private int cantPuertas;

    public Auto(String modelo, String marca, String color, int kilometros, String condicion, int potenciaMotor, String tipoVehiculo, int precio, int cantPuertas) {
        super(modelo, marca, color, kilometros, condicion, potenciaMotor, tipoVehiculo, precio);
        this.cantPuertas = cantPuertas;
    }


    //SETTERS Y GETTERS
    public int getCantPuertas() {
        return this.cantPuertas;
    }

    public void setCantPuertas(int cantPuertas) {
        this.cantPuertas = cantPuertas;
    }

    
}
