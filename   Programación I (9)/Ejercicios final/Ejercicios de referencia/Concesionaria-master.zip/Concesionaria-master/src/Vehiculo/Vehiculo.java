/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vehiculo;

/**
 *
 * @author PROGRAMAR
 */
public abstract class Vehiculo {
    private String modelo;
    private String marca;
    private String color;
    private int kilometros;
    private String condicion;
    private int potenciaMotor;
    private String tipoVehiculo;
    private int precio;
    private int idVehiculo;
    private static int generadorDeId = 1000;
    

    //GETTERS

    public Vehiculo(String modelo, String marca, String color, int kilometros, String condicion, int potenciaMotor,
            String tipoVehiculo, int precio) { //, int idVehiculo) {
        this.modelo = modelo;
        this.marca = marca;
        this.color = color;
        this.kilometros = kilometros;
        this.condicion = condicion;
        this.potenciaMotor = potenciaMotor;
        this.tipoVehiculo = tipoVehiculo;
        this.precio = precio;
        //Creería que el ID se lo podríamos ir asignando nosotros no que se pase como parámetro
        //this.idVehiculo = idVehiculo;
        this.idVehiculo = generarID();
    }

    private int generarID() {
        ++generadorDeId;
        return generadorDeId;
    }
    
    public String getModelo(){
        return this.modelo;
    }

    public String getMarca(){
        return this.marca;
    }

    public String getColor(){
        return this.color;
    }

    public String getCondicion(){
        return this.condicion;
    }

    public String tipoVehiculo(){
        return this.tipoVehiculo;
    }

    public int getKms(){
        return this.kilometros;
    }

    public int getPotenciaMotor(){
        return this.potenciaMotor;
    }

    public int getPrecio(){
        return this.precio;
    }

    public int getIdVehiculo(){
        return this.idVehiculo;
    }

    //-------------------------------------------------------

    //SETTERS

    public void setModelo(String Modelo){
        this.modelo = Modelo;
    }

    public void setMarca(String Marca){
        this.marca = Marca;
    }

    public void setColor(String Color){
        this.color = Color;
    }

    public void setKms(int Kilometros){
        this.kilometros = Kilometros;
    }

    public void setCondicion(String Condicion){
        this.condicion = Condicion;
    }

    public void setPotenciaMotor(int Potencia){
        this.potenciaMotor = Potencia;
    }

    public void setTipoVehiculo(String Tipo){
        this.tipoVehiculo = Tipo;
    }

    public void setPrecio(int precio){
        this.precio = precio;
    }

    public void setIdVehiculo(int id){
        this.idVehiculo = id;
    }

    //-------------------------------------------------------------

    //METODOS PROPIOS

    public void arrancar(){
        System.out.println("ARRANCAR");
    }

    public void detener(){
        System.out.println("DETENER");
    }

    public void acelerar(){
        System.out.println("acelerar");
    }

    public void frenar(){
        System.out.println("FRENAR");
    }

    public void mostrarDatos() {
        System.out.println("Marca: " + this.marca + "\n" + "Modelo: " + this.modelo + "\n" + "Color: " + this.color +"\n" + "Condición: " + this.condicion + "\n" + "Tipo: " +this.tipoVehiculo + "\n"  + "Cantidad de kilómetros: " + this.kilometros + "\n" + "Potencia: " + this.potenciaMotor + "\n" + "Precio: " + this.precio);
    }
}
