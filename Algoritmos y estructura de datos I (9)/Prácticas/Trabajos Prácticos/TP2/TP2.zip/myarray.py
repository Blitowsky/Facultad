
def out_of_range(index, start, end):

    if index < start or index >= end:
        return True
    else:
        return False

def search(array, element):

    encontrado = False
    for i in range(0,len(array)):

        if array[i] == element: 
            return i


    if encontrado == False: return None

       

def insert(array, element, index):

    if out_of_range(index, 0, len(array)):
        return None
    else:

        for i in range(len(array)-1,index,-1):

            array[i] = array[i-1]
        
        array[index] = element
          
def delete(array,element):

    encontrado = False

    for i in range(0,len(array)):
        if array[i] == element:
            encontrado = True
            index = i
            
    if encontrado:
        for i in range(index,len(array)-2):
            array[i] = array[i+1]
        array[len(array)-1] = None
        return index
    else: 
        return None
                    
def length(array):
    
    contador = 0
    for i in range(0,len(array)):
        if array[i] != None:
            contador = contador + 1
        
    return contador